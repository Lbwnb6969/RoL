﻿# RoL Test Playbook

## Preflight

1. 完全退出游戏和启动器后重开。
2. 确认测试角色与领地前置满足。

## Console Smoke

- 发现入口：`event rol_relic_discovery.0001`
- Rome：`event rol_quest_rome.0990`
- Munich：`event rol_quest_munich.0990`
- Naxos：`event rol_quest_naxos.0990`

## Reward Smoke

- `effect rol_create_blade_of_mars_effect = yes`
- `effect rol_create_nibelung_star_sphere_effect = yes`

## Failure Smoke

- `effect rol_rome_quest_fail_now_effect = yes`
- `effect rol_munich_quest_fail_now_effect = yes`
- `effect rol_naxos_quest_fail_now_effect = yes`

## Regression Checklist

- 活动窗口可打开
- 成功/失败反馈事件可见
- toast 有副标题
- 终局门槛与文案一致
- 本地化无缺键/乱码
