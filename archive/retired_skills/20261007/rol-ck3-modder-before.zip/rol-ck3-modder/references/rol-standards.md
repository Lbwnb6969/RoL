﻿# RoL Standards

## Source of Truth

- 真源目录：`C:\CK3Mods\RoL`
- 不再维护任何 Documents 侧 RoL 内容镜像。
- 启动器只通过 `Documents\Paradox Interactive\Crusader Kings III\mod\RoL.mod` 的 `path` 指向真源。

## Encoding

- 脚本和本地化文件使用 UTF-8 with BOM。
- 中文本地化统一放在 `localization/simp_chinese`。

## Naming

- 自定义内容统一 `rol_` 前缀。
- 兼容活动键名保留 `activity_rol_`、`phase_rol_` 风格。

## Safety Rules

- 先检索实例，再写新接口。
- 优先修改最小范围，避免一次性大改。
- 不绕过活动主流程直接堆事件。


