﻿# RoL Localization, UI, and Asset Notes

## Localization

- 中英 key 同步新增。
- 对活动失败提示统一使用公共 key（如 `rol_relic_fail_ends_expedition_tt`）。

## Legendary Display Override

- 使用 `common/customizable_localization` 针对 RoL artifact 定向覆盖。
- 覆盖 `ARTIFACT_RARITY_AND_SLOT_TYPE` 时保留 fallback 给非 RoL artifact。

## Text Icon

- `gui/rol_texticons.gui` 定义 `@rol_legendary_icon!`。
- 推荐徽记贴图：`60x60 .dds`（显示约 24x24）。

## Asset Resolution Baseline

- 事件/活动背景：1592x848
- artifact icon：240x240
- text icon：60x60
