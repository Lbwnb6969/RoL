---
name: rol-ck3-modder
description: Build, fix, and validate the CK3 Relics of Legend (RoL) mod. Use this skill for CK3 P-language scripting, activity and event chain work, artifact/UI overrides, localization fixes, console testing, and crash triage. Enforce C:\CK3Mods\RoL as the only source of truth, UTF-8 with BOM for mod files, rol_ naming conventions, and modular template-driven quest chains.
---

# RoL CK3 Modder

## Overview

Execute RoL implementation and bugfix tasks end-to-end.
Explain in Chinese by default, but keep script IDs, keys, and file names in English.

## Hard Constraints

- Treat `C:\CK3Mods\RoL` as the only development source of truth.
- Do not maintain or rely on any Documents-side RoL content mirror.
- Treat `Documents\Paradox Interactive\Crusader Kings III\mod\RoL.mod` as a launcher descriptor only; when visual changes seem ignored, verify that its `path` still points to `C:\CK3Mods\RoL` before touching anything else.
- Save modified CK3 mod script/localization files as UTF-8 with BOM.
- Keep custom IDs under `rol_` conventions (`activity_rol_` and `phase_rol_` are accepted compatibility forms).
- Search existing examples first (`game`, `RICE`, `docs`, `UsePlanguage.md`) before introducing uncertain syntax.
- When editing Chinese/non-ASCII text on Windows, avoid inline Python piped through PowerShell when the script body itself contains Chinese literals; prefer `apply_patch` for small edits, or BOM-safe shell/file writes, then reopen the file to confirm no `????` corruption occurred.

## Workflow

1. Inspect current chain integrity first.
2. Trace the real display/behavior path before editing the wrong layer: localization/custom loc -> scripted effects/triggers -> GUI/assets.
3. For any GFX issue, confirm the actual loading path and the actual wired asset before editing: descriptor/mod path -> explicit script/gui refs -> implicit filename-convention refs -> cache/DDS spec.
4. Apply minimal, modular edits via scripted effects/triggers when possible.
5. For localization/doc repairs, scan for broken `????` text before editing and confirm the repaired file contents after writing.
6. Keep full quest flow: discovery -> activity -> stage checks -> terminal reward/fail.
7. Keep observability: toast title+desc, activity logs, debug traces.
8. Align random probabilities with tooltip text.
9. Run bundled checks before final report.
10. Do not sync or hotfix any Documents-side RoL copy; if needed, only confirm the launcher descriptor still targets `C:\CK3Mods\RoL`.

## Output Contract

Always provide:

- Change summary grouped by behavior
- Key touched paths
- Validation steps with console commands
- Expected outcomes and known risks

Use this report skeleton:

```markdown
## Changes
- ...

## Validation Steps
1. ...
2. ...

## Expected Results
- ...

## Risks / Follow-ups
- ...
```

## Crash and Invalid-ID Triage Order

1. Verify source-of-truth path (`C:\CK3Mods\RoL`).
2. Verify the active launcher descriptor path in `Documents\Paradox Interactive\Crusader Kings III\mod\RoL.mod`; if it points to `C:\CK3Mods\RoL`, always fix `C:\CK3Mods\RoL` itself rather than creating or editing a second content copy under Documents.
3. Fully restart game and launcher.
4. Verify UTF-8 BOM on changed files.
5. Verify namespace, event IDs, on_actions, and load order.
6. Verify `scope:activity` context assumptions.
7. Verify localization keys and encoding.
8. If text appears as `????`, verify file contents/bytes rather than trusting terminal rendering alone.
9. If visual changes or backgrounds do not appear, clear `Documents/Paradox Interactive/Crusader Kings III/gfx`, then re-check background refs, texture paths, filename conventions, and DDS specs before assuming the asset is broken.

## High-Value RoL Heuristics

- Artifact card text, rarity labels, or color issues usually live in localization/custom loc first; inspect `common/customizable_localization` before editing `.gui`.
- Event/activity black backgrounds usually fail in this order: wrong background reference, wrong texture path, bad DDS format/size, stale gfx cache.
- A replaced image that "reverted" often means one of three things: the active descriptor is no longer pointing at `C:\CK3Mods\RoL`, the file exists but is not actually wired, or CK3 is still reading stale gfx cache.
- For activity UI art, remember many assets are wired implicitly by exact filename/activity-id convention rather than explicit script references; verify naming before touching GUI.
- Current RoL visual baseline: event/activity backgrounds target `1592x848` DDS (`DXT1/BC1`, no alpha, unless transparency is truly needed); artifact icons target `240x240`; regiment icons `120x120`; activity icons `80x80`; header icons `164x164`.
- When repairing large Chinese localization/doc files, treat encoding safety as part of the fix: write with BOM, reopen with `utf-8-sig`, and re-scan for `????`.

## Bundled Resources

- `references/rol-standards.md`
- `references/rol-activity-template.md`
- `references/rol-localization-ui-assets.md`
- `references/rol-test-playbook.md`
- `scripts/check_bom_utf8.py`
- `scripts/check_rol_prefix.py`
- `scripts/rol_smoke_checks.py`

